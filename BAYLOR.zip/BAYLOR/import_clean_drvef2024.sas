/* ============================================================
   PROGRAM  : import_clean_drvef2024.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Fall Enrollment 2024
   SOURCE   : drvef2024.csv
   OUTPUT   : BAYDATA.clean_drvef2024
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Add institution name, Baylor flag, academic year
     - COALESCE 13 null DVEF flag columns to 0
     - Apply descriptive variable labels
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

/* Import raw CSV */
PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\drvef2024.csv"
    OUT      = BAYDATA.raw_drvef2024
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;

/* Clean and save as permanent dataset */
DATA BAYDATA.clean_drvef2024;
    SET BAYDATA.raw_drvef2024;

    WHERE UNITID IN (
        223232,   /* Baylor University              */
        228875,   /* Texas Christian University     */
        228246,   /* Southern Methodist University  */
        228723,   /* Texas A&M University           */
        228778,   /* University of Texas at Austin  */
        162928,   /* Johns Hopkins University       */
        221999    /* Vanderbilt University          */
    );

    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;

    IS_BAYLOR = (UNITID = 223232);
    ACAD_YEAR = 2024;

    IF DVEF01 = . THEN DVEF01 = 0;
    IF DVEF02 = . THEN DVEF02 = 0;
    IF DVEF03 = . THEN DVEF03 = 0;
    IF DVEF05 = . THEN DVEF05 = 0;
    IF DVEF06 = . THEN DVEF06 = 0;
    IF DVEF07 = . THEN DVEF07 = 0;
    IF DVEF09 = . THEN DVEF09 = 0;
    IF DVEF10 = . THEN DVEF10 = 0;
    IF DVEF11 = . THEN DVEF11 = 0;
    IF DVEF13 = . THEN DVEF13 = 0;
    IF DVEF14 = . THEN DVEF14 = 0;
    IF DVEF15 = . THEN DVEF15 = 0;
    IF DVEF16 = . THEN DVEF16 = 0;

    LABEL
        UNITID    = 'Institution UNITID'
        INST_NAME = 'Institution Name'
        ACAD_YEAR = 'Academic Year'
        IS_BAYLOR = 'Baylor Flag (1=Yes)'
        ENRTOT    = 'Total Enrollment'
        FTE       = 'FTE Enrollment'
        ENRFT     = 'Full-Time Enrollment'
        ENRPT     = 'Part-Time Enrollment'
        EFUG      = 'Undergrad Enrollment'
        EFGRAD    = 'Graduate Enrollment'
        EFUG1ST   = 'First-Time Freshmen'
        EFUGTRN   = 'Transfer Students'
        EFUGCNT   = 'Continuing Students'
        PCTENRWH  = 'Pct White'
        PCTENRBK  = 'Pct Black/African American'
        PCTENRHS  = 'Pct Hispanic/Latino'
        PCTENRAS  = 'Pct Asian'
        PCTENR2M  = 'Pct Two or More Races'
        PCTENRNR  = 'Pct Nonresident Alien'
        PCTENRW   = 'Pct Women'
        RMINSTTN  = 'Freshmen In-State Count'
        RMOUSTTN  = 'Freshmen Out-of-State Count'
        RMINSTTP  = 'Pct Freshmen In-State'
        RMOUSTTP  = 'Pct Freshmen Out-of-State'
        PCTDEEXC  = 'Pct Exclusively Distance Ed'
        PCTDESOM  = 'Pct Some Distance Ed'
        PCTDENON  = 'Pct No Distance Ed';
RUN;

PROC PRINT DATA = BAYDATA.CLEAN_DRVEF2024 NOOBS;
    VAR UNITID INST_NAME ACAD_YEAR ENRTOT EFUG
        EFGRAD PCTENRHS PCTENRW IS_BAYLOR;
    TITLE 'CLEAN_DRVEF2024 7 Peer Institutions';
RUN;
