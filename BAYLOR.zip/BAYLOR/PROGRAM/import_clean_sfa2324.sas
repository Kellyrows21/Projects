/* ============================================================
   PROGRAM  : import_clean_sfa2324.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Student Financial Aid
   SOURCE   : sfa2324.csv
   OUTPUT   : BAYDATA.clean_sfa2324
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Add institution name, Baylor flag, academic year
     - Drop all 60+ X-flag indicator columns
     - COALESCE sub-cohort count nulls to 0
       SCFY2, SCFY2DG, SCFY2ND = 2nd year cohort counts
       SCFY1N, SCFY1P = 1st year net price counts
       Null = institution did not report sub-cohort
     - Leave avg dollar amount nulls as missing (.)
       UNDAGRNTA, UNDPGRNTA, UNDFLOANA = null means
       no students in that category (not an error)
     - Keep core analysis columns only
     - Apply variable labels
   NOTE: sfa2324 covers FIRST-TIME FULL-TIME undergrads only.
         Not all enrolled students. State this in analysis.
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";
PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\sfa2324.csv"
    OUT      = BAYDATA.raw_sfa2324
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;
DATA BAYDATA.clean_sfa2324;
    SET BAYDATA.raw_sfa2324;
    WHERE UNITID IN (223232,228875,228246,228723,228778,162928,221999);
    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;
    IS_BAYLOR = (UNITID = 223232);
    ACAD_YEAR = 2024;
    /* COALESCE sub-cohort count nulls to 0                   */
    IF SCFY2   = . THEN SCFY2   = 0;
    IF SCFY2DG = . THEN SCFY2DG = 0;
    IF SCFY2ND = . THEN SCFY2ND = 0;
    IF SCFY1N  = . THEN SCFY1N  = 0;
    IF SCFY1P  = . THEN SCFY1P  = 0;
    LABEL
        UNITID    = 'Institution UNITID'
        INST_NAME = 'Institution Name'
        IS_BAYLOR = 'Baylor Flag (1=Yes)'
        ACAD_YEAR = 'Academic Year'
        SCUGRAD   = 'Total Undergrad Students Reported'
        SCUGDGSK  = 'Degree-Seeking Undergrads'
        ANYAIDN   = 'Students Receiving Any Aid (N)'
        ANYAIDP   = 'Pct Students Receiving Any Aid'
        AGRNT_N   = 'Students with Any Grant (N)'
        AGRNT_P   = 'Pct with Any Grant'
        AGRNT_A   = 'Avg Grant Amount ($)'
        FGRNT_N   = 'Students with Pell Grant (N)'
        FGRNT_P   = 'Pct with Pell Grant'
        FGRNT_A   = 'Avg Pell Grant Amount ($)'
        IGRNT_N   = 'Students with Inst Grant (N)'
        IGRNT_P   = 'Pct with Institutional Grant'
        IGRNT_A   = 'Avg Institutional Grant Amount ($)'
        LOAN_N    = 'Students with Any Loan (N)'
        LOAN_P    = 'Pct with Any Loan'
        LOAN_A    = 'Avg Loan Amount ($)';
    /* Keep core analysis columns — drop all X-flag columns   */
    KEEP UNITID INST_NAME IS_BAYLOR ACAD_YEAR
         SCUGRAD SCUGDGSK SCUGFFN SCUGFFP
         ANYAIDN ANYAIDP
         AGRNT_N AGRNT_P AGRNT_T AGRNT_A
         FGRNT_N FGRNT_P FGRNT_T FGRNT_A
         PGRNT_N PGRNT_P PGRNT_T PGRNT_A
         IGRNT_N IGRNT_P IGRNT_T IGRNT_A
         LOAN_N  LOAN_P  LOAN_T  LOAN_A
         FLOAN_N FLOAN_P FLOAN_T FLOAN_A
         SCFY2 SCFY2DG SCFY2ND SCFY1N SCFY1P;
RUN;
PROC PRINT DATA = BAYDATA.CLEAN_SFA2324 NOOBS;
    VAR UNITID INST_NAME SCUGRAD ANYAIDP
        FGRNT_P FGRNT_A IGRNT_P IGRNT_A
        LOAN_P LOAN_A IS_BAYLOR;
    TITLE 'CLEAN_SFA2324 Financial Aid DATA';
    FORMAT FGRNT_A IGRNT_A LOAN_A AGRNT_A DOLLAR10.0
           ANYAIDP FGRNT_P IGRNT_P LOAN_P 5.1;
RUN;
