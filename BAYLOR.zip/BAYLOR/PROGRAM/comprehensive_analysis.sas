/* ============================================================
   PROGRAM  : comprehensive_analysis.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Comprehensive Enrollment Analytics  Baylor
              University vs Peer Institutions 2021-2024
   INPUT    : All 10 BAYDATA.clean_* datasets
   NOTE     : UNITID is Char(6) in clean_hd2024 but Num in
              all other datasets. All joins use PUT() to
              convert Num UNITID to Char for matching.
   ANALYSES :
     SECTION 1   Enrollment Trends 2021-2024
     SECTION 2   Enrollment Composition
     SECTION 3   Student Demographics and Diversity
     SECTION 4   Geographic Draw of Freshmen
     SECTION 5   Graduation Rates (150% time)
     SECTION 6   Retention Rates
     SECTION 7   Financial Aid and Affordability
     SECTION 8   Distance Education
     SECTION 9   Peer Benchmarking Summary
     SECTION 10  Statistical Models
     SECTION 11  Export Gold Layer for Power BI
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

OPTIONS NODATE NONUMBER;
ODS GRAPHICS ON;

TITLE  "Baylor University Enrollment Analytics  2021 to 2024";
TITLE2 "Analyst: Kelly Adu-Gyamfi";


/* ============================================================
   SECTION 1  ENROLLMENT TRENDS 2021-2024
   Stack 4 years into one longitudinal table
   ============================================================ */

TITLE3 "SECTION 1: Enrollment Trends 2021-2024";

DATA WORK.enroll_trend;
    SET BAYDATA.clean_drvef2021 (KEEP=UNITID INST_NAME ACAD_YEAR
                                      ENRTOT FTE ENRFT ENRPT
                                      EFUG EFGRAD PCTENRHS
                                      PCTENRW IS_BAYLOR)
        BAYDATA.clean_drvef2022 (KEEP=UNITID INST_NAME ACAD_YEAR
                                      ENRTOT FTE ENRFT ENRPT
                                      EFUG EFGRAD PCTENRHS
                                      PCTENRW IS_BAYLOR)
        BAYDATA.clean_drvef2023 (KEEP=UNITID INST_NAME ACAD_YEAR
                                      ENRTOT FTE ENRFT ENRPT
                                      EFUG EFGRAD PCTENRHS
                                      PCTENRW IS_BAYLOR)
        BAYDATA.clean_drvef2024 (KEEP=UNITID INST_NAME ACAD_YEAR
                                      ENRTOT FTE ENRFT ENRPT
                                      EFUG EFGRAD PCTENRHS
                                      PCTENRW IS_BAYLOR);

    IF ENRTOT > 0 THEN
        GRAD_SHARE_PCT = ROUND(EFGRAD / ENRTOT * 100, 0.1);
    ELSE GRAD_SHARE_PCT = .;

    IF ENRTOT > 0 THEN
        FT_RATE_PCT = ROUND(ENRFT / ENRTOT * 100, 0.1);
    ELSE FT_RATE_PCT = .;

    LABEL
        ENRTOT         = 'Total Enrollment'
        EFUG           = 'Undergraduate Enrollment'
        EFGRAD         = 'Graduate Enrollment'
        GRAD_SHARE_PCT = 'Graduate Share Pct'
        FT_RATE_PCT    = 'Full-Time Rate Pct'
        PCTENRHS       = 'Pct Hispanic'
        PCTENRW        = 'Pct Women';
RUN;

/* 1A: Enrollment by institution and year */
PROC TABULATE DATA=WORK.enroll_trend FORMAT=COMMA10.;
    CLASS  INST_NAME ACAD_YEAR;
    VAR    ENRTOT;
    TABLE  INST_NAME,
           ACAD_YEAR * ENRTOT * SUM = ' '
           / BOX='Total Enrollment by Year';
    TITLE3 "1A: Total Enrollment by Institution and Year";
RUN;

/* 1B: Baylor trend line chart */
PROC SGPLOT DATA=WORK.enroll_trend;
    WHERE IS_BAYLOR = 1;
    SERIES X=ACAD_YEAR Y=ENRTOT /
        MARKERS MARKERATTRS=(SYMBOL=CIRCLEFILLED)
        LINEATTRS=(COLOR=DARKBLUE THICKNESS=2)
        LEGENDLABEL='Total';
    SERIES X=ACAD_YEAR Y=EFUG /
        MARKERS MARKERATTRS=(SYMBOL=SQUAREFILLED)
        LINEATTRS=(COLOR=GREEN THICKNESS=2)
        LEGENDLABEL='Undergraduate';
    SERIES X=ACAD_YEAR Y=EFGRAD /
        MARKERS MARKERATTRS=(SYMBOL=TRIANGLEFILLED)
        LINEATTRS=(COLOR=RED THICKNESS=2)
        LEGENDLABEL='Graduate';
    XAXIS LABEL='Academic Year' VALUES=(2021 2022 2023 2024) INTEGER;
    YAXIS LABEL='Number of Students' FORMAT=COMMA10.;
    KEYLEGEND / TITLE='Enrollment Type';
    TITLE3 "1B: Baylor University Enrollment Trend 2021-2024";
RUN;

/* 1C: All peers trend panel */
PROC SGPANEL DATA=WORK.enroll_trend;
    PANELBY INST_NAME / COLUMNS=2 NOVARNAME;
    SERIES  X=ACAD_YEAR Y=ENRTOT /
        MARKERS LINEATTRS=(THICKNESS=2);
    COLAXIS LABEL='Year' VALUES=(2021 2022 2023 2024) INTEGER;
    ROWAXIS LABEL='Total Enrollment' FORMAT=COMMA10.;
    TITLE3  "1C: Enrollment Trend — All 7 Peer Institutions";
RUN;

/* 1D: Baylor year-over-year change */
PROC SQL;
    CREATE TABLE WORK.baylor_yoy AS
    SELECT
        ACAD_YEAR,
        ENRTOT,
        LAG(ENRTOT) OVER (ORDER BY ACAD_YEAR) AS PRIOR_ENRTOT,
        ENRTOT - LAG(ENRTOT) OVER (ORDER BY ACAD_YEAR)
            AS ENROLL_CHANGE,
        ROUND((ENRTOT - LAG(ENRTOT) OVER (ORDER BY ACAD_YEAR))
            / LAG(ENRTOT) OVER (ORDER BY ACAD_YEAR) * 100, 0.1)
            AS ENROLL_CHANGE_PCT
    FROM WORK.enroll_trend
    WHERE IS_BAYLOR = 1
    ORDER BY ACAD_YEAR;
QUIT;

PROC PRINT DATA=WORK.baylor_yoy NOOBS LABEL;
    VAR ACAD_YEAR ENRTOT PRIOR_ENRTOT
        ENROLL_CHANGE ENROLL_CHANGE_PCT;
    FORMAT ENRTOT PRIOR_ENRTOT ENROLL_CHANGE COMMA10.
           ENROLL_CHANGE_PCT 6.1;
    LABEL ENROLL_CHANGE     = 'Change from Prior Year'
          ENROLL_CHANGE_PCT = 'Pct Change';
    TITLE3 "1D: Baylor Year-Over-Year Enrollment Change";
RUN;


/* ============================================================
   SECTION 2 — ENROLLMENT COMPOSITION
   ============================================================ */

TITLE3 "SECTION 2: Enrollment Composition 2024";

PROC SQL;
    CREATE TABLE WORK.composition AS
    SELECT
        INST_NAME,
        ENRTOT,
        EFUG,
        EFGRAD,
        ROUND(EFUG   / ENRTOT * 100, 0.1) AS UG_PCT,
        ROUND(EFGRAD / ENRTOT * 100, 0.1) AS GRAD_PCT,
        ENRFT,
        ENRPT,
        ROUND(ENRFT  / ENRTOT * 100, 0.1) AS FT_PCT,
        IS_BAYLOR
    FROM BAYDATA.clean_drvef2024
    ORDER BY IS_BAYLOR DESC, ENRTOT DESC;
QUIT;

PROC PRINT DATA=WORK.composition NOOBS LABEL;
    VAR INST_NAME ENRTOT EFUG EFGRAD UG_PCT GRAD_PCT
        ENRFT ENRPT FT_PCT;
    FORMAT ENRTOT EFUG EFGRAD ENRFT ENRPT COMMA10.
           UG_PCT GRAD_PCT FT_PCT 5.1;
    LABEL INST_NAME = 'Institution'
          ENRTOT    = 'Total'
          UG_PCT    = 'UG Pct'
          GRAD_PCT  = 'Grad Pct'
          FT_PCT    = 'Full-Time Pct';
    TITLE3 "2A: Enrollment Composition — All Peers 2024";
RUN;

DATA WORK.comp_long;
    SET WORK.composition;
    LENGTH ENROLL_TYPE $ 15;
    ENROLL_TYPE = 'Undergraduate'; COUNT = EFUG;   OUTPUT;
    ENROLL_TYPE = 'Graduate';      COUNT = EFGRAD; OUTPUT;
    KEEP INST_NAME ENROLL_TYPE COUNT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.comp_long;
    VBAR  INST_NAME / RESPONSE=COUNT GROUP=ENROLL_TYPE
                      GROUPDISPLAY=STACK DATALABEL;
    XAXIS LABEL=' ' FITPOLICY=ROTATE;
    YAXIS LABEL='Students' FORMAT=COMMA10.;
    KEYLEGEND / TITLE='Enrollment Type';
    TITLE3 "2B: Undergraduate vs Graduate Enrollment — 2024";
RUN;


/* ============================================================
   SECTION 3 — STUDENT DEMOGRAPHICS AND DIVERSITY
   ============================================================ */

TITLE3 "SECTION 3: Student Demographics 2024";

PROC SQL;
    CREATE TABLE WORK.demographics AS
    SELECT
        INST_NAME,
        PCTENRWH AS PCT_WHITE,
        PCTENRBK AS PCT_BLACK,
        PCTENRHS AS PCT_HISPANIC,
        PCTENRAS AS PCT_ASIAN,
        PCTENR2M AS PCT_MULTIRACE,
        PCTENRNR AS PCT_NONRESIDENT,
        PCTENRW  AS PCT_WOMEN,
        IS_BAYLOR
    FROM BAYDATA.clean_drvef2024
    ORDER BY IS_BAYLOR DESC, INST_NAME;
QUIT;

PROC PRINT DATA=WORK.demographics NOOBS LABEL;
    VAR INST_NAME PCT_WHITE PCT_BLACK PCT_HISPANIC
        PCT_ASIAN PCT_MULTIRACE PCT_NONRESIDENT PCT_WOMEN;
    FORMAT PCT_WHITE PCT_BLACK PCT_HISPANIC PCT_ASIAN
           PCT_MULTIRACE PCT_NONRESIDENT PCT_WOMEN 5.1;
    LABEL INST_NAME       = 'Institution'
          PCT_WHITE       = '% White'
          PCT_BLACK       = '% Black'
          PCT_HISPANIC    = '% Hispanic'
          PCT_ASIAN       = '% Asian'
          PCT_MULTIRACE   = '% Two+ Races'
          PCT_NONRESIDENT = '% Nonresident'
          PCT_WOMEN       = '% Women';
    TITLE3 "3A: Race/Ethnicity and Gender — All Peers 2024";
RUN;

/* 3B: Baylor Hispanic trend */
PROC SGPLOT DATA=WORK.enroll_trend;
    WHERE IS_BAYLOR = 1;
    SERIES X=ACAD_YEAR Y=PCTENRHS /
        MARKERS MARKERATTRS=(SYMBOL=CIRCLEFILLED SIZE=10)
        LINEATTRS=(COLOR=DARKGREEN THICKNESS=2);
    REFLINE 17 / AXIS=Y LABEL='2024 Level (17%)'
                 LINEATTRS=(PATTERN=DASH COLOR=GRAY);
    XAXIS LABEL='Academic Year' VALUES=(2021 2022 2023 2024) INTEGER;
    YAXIS LABEL='Percent Hispanic/Latino' MIN=0 MAX=25;
    TITLE3 "3B: Baylor Hispanic Enrollment Trend 2021-2024";
RUN;

/* 3C: Diversity grouped bar */
DATA WORK.diversity_long;
    SET WORK.demographics;
    LENGTH RACE_ETHNICITY $ 25;
    RACE_ETHNICITY = 'White';           PCT = PCT_WHITE;       OUTPUT;
    RACE_ETHNICITY = 'Hispanic/Latino'; PCT = PCT_HISPANIC;    OUTPUT;
    RACE_ETHNICITY = 'Black/Afr Amer';  PCT = PCT_BLACK;       OUTPUT;
    RACE_ETHNICITY = 'Asian';           PCT = PCT_ASIAN;       OUTPUT;
    RACE_ETHNICITY = 'Nonresident';     PCT = PCT_NONRESIDENT; OUTPUT;
    KEEP INST_NAME RACE_ETHNICITY PCT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.diversity_long;
    VBAR  INST_NAME / RESPONSE=PCT GROUP=RACE_ETHNICITY
                      GROUPDISPLAY=CLUSTER;
    XAXIS LABEL=' ' FITPOLICY=ROTATE;
    YAXIS LABEL='Percent of Enrollment' MIN=0 MAX=80;
    KEYLEGEND / TITLE='Race/Ethnicity' POSITION=TOPRIGHT;
    TITLE3 "3C: Enrollment by Race/Ethnicity — All Peers 2024";
RUN;


/* ============================================================
   SECTION 4 — GEOGRAPHIC DRAW OF FRESHMEN
   ============================================================ */

TITLE3 "SECTION 4: Geographic Draw of First-Time Freshmen 2024";

PROC SQL;
    CREATE TABLE WORK.residency AS
    SELECT
        INST_NAME,
        RMINSTTN AS INSTATE_N,
        RMOUSTTN AS OUTSTATE_N,
        RMFRGNCN AS FOREIGN_N,
        RMINSTTP AS INSTATE_PCT,
        RMOUSTTP AS OUTSTATE_PCT,
        IS_BAYLOR
    FROM BAYDATA.clean_drvef2024
    ORDER BY IS_BAYLOR DESC, INSTATE_PCT DESC;
QUIT;

PROC PRINT DATA=WORK.residency NOOBS LABEL;
    VAR INST_NAME INSTATE_N OUTSTATE_N FOREIGN_N
        INSTATE_PCT OUTSTATE_PCT;
    FORMAT INSTATE_N OUTSTATE_N FOREIGN_N COMMA8.
           INSTATE_PCT OUTSTATE_PCT 5.1;
    LABEL INST_NAME    = 'Institution'
          INSTATE_N    = 'In-State (N)'
          OUTSTATE_N   = 'Out-of-State (N)'
          FOREIGN_N    = 'Foreign (N)'
          INSTATE_PCT  = 'In-State Pct'
          OUTSTATE_PCT = 'Out-of-State Pct';
    TITLE3 "4A: Freshmen Residency — All Peers 2024";
RUN;

DATA WORK.residency_long;
    SET WORK.residency;
    LENGTH RESIDENCY $ 15;
    RESIDENCY = 'In-State';     PCT = INSTATE_PCT;  OUTPUT;
    RESIDENCY = 'Out-of-State'; PCT = OUTSTATE_PCT; OUTPUT;
    KEEP INST_NAME RESIDENCY PCT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.residency_long;
    HBAR  INST_NAME / RESPONSE=PCT GROUP=RESIDENCY
                      GROUPDISPLAY=STACK DATALABEL;
    XAXIS LABEL='Percent of First-Time Freshmen' MIN=0 MAX=105;
    YAXIS LABEL=' ';
    KEYLEGEND / TITLE='Residency';
    TITLE3 "4B: Freshmen Geographic Draw — All Peers 2024";
RUN;


/* ============================================================
   SECTION 5 — GRADUATION RATES
   NOTE: UNITID is Char in clean_hd2024 and Num in
         clean_drvgr2024. Use PUT() to convert for join.
   ============================================================ */

TITLE3 "SECTION 5: Graduation Rates (150% Time) 2024";

PROC SQL;
    CREATE TABLE WORK.grad_rates AS
    SELECT
        d.INSTNM        AS INST_NAME,
        g.GBA4RTT       AS GRAD_RATE_4YR,
        g.GBA5RTT       AS GRAD_RATE_5YR,
        g.GBA6RTT       AS GRAD_RATE_6YR,
        g.GBA6RTM       AS GRAD_RATE_MEN,
        g.GBA6RTW       AS GRAD_RATE_WOMEN,
        g.GBA6RTBK      AS GRAD_RATE_BLACK,
        g.GBA6RTHS      AS GRAD_RATE_HISP,
        g.GBA6RTWH      AS GRAD_RATE_WHITE,
        g.PGGRRTT       AS GRAD_RATE_PELL,
        g.NRGRRTT       AS GRAD_RATE_NOPELL,
        d.IS_BAYLOR
    FROM BAYDATA.clean_drvgr2024 g
    JOIN BAYDATA.clean_hd2024    d
        ON PUT(g.UNITID, 6.) = d.UNITID
    ORDER BY d.IS_BAYLOR DESC, g.GBA6RTT DESC;
QUIT;

PROC PRINT DATA=WORK.grad_rates NOOBS LABEL;
    VAR INST_NAME GRAD_RATE_4YR GRAD_RATE_5YR GRAD_RATE_6YR
        GRAD_RATE_MEN GRAD_RATE_WOMEN;
    FORMAT GRAD_RATE_4YR GRAD_RATE_5YR GRAD_RATE_6YR
           GRAD_RATE_MEN GRAD_RATE_WOMEN 5.1;
    LABEL INST_NAME       = 'Institution'
          GRAD_RATE_4YR   = '4-Year Rate'
          GRAD_RATE_5YR   = '5-Year Rate'
          GRAD_RATE_6YR   = '6-Year Rate'
          GRAD_RATE_MEN   = 'Men 6-Yr'
          GRAD_RATE_WOMEN = 'Women 6-Yr';
    TITLE3 "5A: Graduation Rates by Year and Gender — 2024";
RUN;

PROC PRINT DATA=WORK.grad_rates NOOBS LABEL;
    VAR INST_NAME GRAD_RATE_6YR GRAD_RATE_WHITE
        GRAD_RATE_BLACK GRAD_RATE_HISP
        GRAD_RATE_PELL GRAD_RATE_NOPELL;
    FORMAT GRAD_RATE_6YR GRAD_RATE_WHITE GRAD_RATE_BLACK
           GRAD_RATE_HISP GRAD_RATE_PELL GRAD_RATE_NOPELL 5.1;
    LABEL INST_NAME        = 'Institution'
          GRAD_RATE_6YR    = 'Overall 6-Yr'
          GRAD_RATE_WHITE  = 'White'
          GRAD_RATE_BLACK  = 'Black'
          GRAD_RATE_HISP   = 'Hispanic'
          GRAD_RATE_PELL   = 'Pell Recipients'
          GRAD_RATE_NOPELL = 'Non-Recipients';
    TITLE3 "5B: Graduation Rates by Race/Ethnicity and Pell Status";
RUN;

PROC SGPLOT DATA=WORK.grad_rates;
    HBAR  INST_NAME / RESPONSE=GRAD_RATE_6YR DATALABEL
                      FILLATTRS=(COLOR=STEELBLUE);
    REFLINE 80 / AXIS=X LABEL='Baylor (80%)'
                 LINEATTRS=(PATTERN=DASH COLOR=DARKGREEN THICKNESS=2);
    XAXIS LABEL='6-Year Graduation Rate (%)' MIN=0 MAX=100;
    YAXIS LABEL=' ';
    TITLE3 "5C: 6-Year Graduation Rate — All Peers 2024";
RUN;

/* 5D: Baylor equity gap */
PROC SQL;
    CREATE TABLE WORK.equity_gap AS
    SELECT
        'Baylor University'      AS INSTITUTION,
        GBA6RTT                  AS OVERALL_RATE,
        GBA6RTWH                 AS WHITE_RATE,
        GBA6RTBK                 AS BLACK_RATE,
        GBA6RTHS                 AS HISPANIC_RATE,
        GBA6RTWH - GBA6RTBK     AS WHITE_BLACK_GAP,
        GBA6RTWH - GBA6RTHS     AS WHITE_HISPANIC_GAP,
        NRGRRTT                  AS NON_PELL_RATE,
        PGGRRTT                  AS PELL_RATE,
        NRGRRTT - PGGRRTT       AS PELL_EQUITY_GAP
    FROM BAYDATA.clean_drvgr2024
    WHERE UNITID = 223232;
QUIT;

PROC PRINT DATA=WORK.equity_gap NOOBS LABEL;
    FORMAT OVERALL_RATE WHITE_RATE BLACK_RATE HISPANIC_RATE
           WHITE_BLACK_GAP WHITE_HISPANIC_GAP
           NON_PELL_RATE PELL_RATE PELL_EQUITY_GAP 5.1;
    LABEL OVERALL_RATE       = 'Overall 6-Yr Rate'
          WHITE_RATE         = 'White Rate'
          BLACK_RATE         = 'Black Rate'
          HISPANIC_RATE      = 'Hispanic Rate'
          WHITE_BLACK_GAP    = 'White-Black Gap'
          WHITE_HISPANIC_GAP = 'White-Hispanic Gap'
          PELL_EQUITY_GAP    = 'Non-Pell vs Pell Gap';
    TITLE3 "5D: Baylor Equity Gaps in Graduation Rates";
RUN;


/* ============================================================
   SECTION 6 — RETENTION RATES
   NOTE: UNITID is Char in clean_hd2024 and Num in
         clean_ef2024d. Use PUT() to convert for join.
   ============================================================ */

TITLE3 "SECTION 6: Retention Rates 2024";

PROC SQL;
    CREATE TABLE WORK.retention AS
    SELECT
        d.INSTNM           AS INST_NAME,
        e.GRCOHRT          AS COHORT_SIZE,
        e.RRFTCT           AS STUDENTS_RETAINED,
        e.RET_PCF          AS RETENTION_RATE_PCT,
        e.STUFACR          AS STUDENT_FACULTY_RATIO,
        d.IS_BAYLOR
    FROM BAYDATA.clean_ef2024d e
    JOIN BAYDATA.clean_hd2024  d
        ON PUT(e.UNITID, 6.) = d.UNITID
    ORDER BY d.IS_BAYLOR DESC, e.RET_PCF DESC;
QUIT;

PROC PRINT DATA=WORK.retention NOOBS LABEL;
    VAR INST_NAME COHORT_SIZE STUDENTS_RETAINED
        RETENTION_RATE_PCT STUDENT_FACULTY_RATIO;
    FORMAT COHORT_SIZE STUDENTS_RETAINED COMMA8.
           RETENTION_RATE_PCT 5.1;
    LABEL INST_NAME             = 'Institution'
          COHORT_SIZE           = 'Cohort Size'
          STUDENTS_RETAINED     = 'Retained (N)'
          RETENTION_RATE_PCT    = 'Retention Rate Pct'
          STUDENT_FACULTY_RATIO = 'Student:Faculty Ratio';
    TITLE3 "6A: First-Year Retention Rates — All Peers 2024";
RUN;

PROC SGPLOT DATA=WORK.retention;
    HBAR  INST_NAME / RESPONSE=RETENTION_RATE_PCT DATALABEL
                      FILLATTRS=(COLOR=FORESTGREEN);
    XAXIS LABEL='First-Year Retention Rate (%)' MIN=80 MAX=100;
    YAXIS LABEL=' ';
    TITLE3 "6B: First-Year Retention Rate — All Peers 2024";
RUN;

/* 6C: Baylor retention trend — values from clean datasets */
DATA WORK.baylor_retention_trend;
    LENGTH INST_NAME $ 40;
    INST_NAME = 'Baylor University';
    ACAD_YEAR = 2021; RETENTION_RATE_PCT = 88; OUTPUT;
    ACAD_YEAR = 2022; RETENTION_RATE_PCT = 90; OUTPUT;
    ACAD_YEAR = 2023; RETENTION_RATE_PCT = 91; OUTPUT;
    ACAD_YEAR = 2024; RETENTION_RATE_PCT = 91; OUTPUT;
RUN;

PROC SGPLOT DATA=WORK.baylor_retention_trend;
    SERIES X=ACAD_YEAR Y=RETENTION_RATE_PCT /
        MARKERS MARKERATTRS=(SYMBOL=CIRCLEFILLED SIZE=10)
        LINEATTRS=(COLOR=FORESTGREEN THICKNESS=2);
    XAXIS LABEL='Academic Year' VALUES=(2021 2022 2023 2024) INTEGER;
    YAXIS LABEL='Retention Rate Pct' MIN=85 MAX=95;
    TITLE3 "6C: Baylor First-Year Retention Rate Trend 2021-2024";
RUN;


/* ============================================================
   SECTION 7 — FINANCIAL AID AND AFFORDABILITY
   ============================================================ */

TITLE3 "SECTION 7: Financial Aid and Affordability 2023-24";

PROC SQL;
    CREATE TABLE WORK.financial_aid AS
    SELECT
        INST_NAME,
        SCUGRAD     AS TOTAL_UNDERGRADS,
        ANYAIDP     AS PCT_ANY_AID,
        FGRNT_P     AS PCT_PELL,
        FGRNT_A     AS AVG_PELL_AMT,
        IGRNT_P     AS PCT_INST_GRANT,
        IGRNT_A     AS AVG_INST_GRANT,
        LOAN_P      AS PCT_LOANS,
        LOAN_A      AS AVG_LOAN_AMT,
        IS_BAYLOR
    FROM BAYDATA.clean_sfa2324
    ORDER BY IS_BAYLOR DESC, PCT_INST_GRANT DESC;
QUIT;

PROC PRINT DATA=WORK.financial_aid NOOBS LABEL;
    VAR INST_NAME TOTAL_UNDERGRADS PCT_ANY_AID
        PCT_PELL AVG_PELL_AMT PCT_INST_GRANT
        AVG_INST_GRANT PCT_LOANS AVG_LOAN_AMT;
    FORMAT TOTAL_UNDERGRADS COMMA10.
           AVG_PELL_AMT AVG_INST_GRANT AVG_LOAN_AMT DOLLAR10.0
           PCT_ANY_AID PCT_PELL PCT_INST_GRANT PCT_LOANS 5.1;
    LABEL INST_NAME       = 'Institution'
          TOTAL_UNDERGRADS= 'Total UG'
          PCT_ANY_AID     = '% Any Aid'
          PCT_PELL        = '% Pell'
          AVG_PELL_AMT    = 'Avg Pell'
          PCT_INST_GRANT  = '% Inst Grant'
          AVG_INST_GRANT  = 'Avg Inst Grant'
          PCT_LOANS       = '% Loans'
          AVG_LOAN_AMT    = 'Avg Loan';
    TITLE3 "7A: Financial Aid Summary — All Peers 2023-24";
RUN;

DATA WORK.aid_long;
    SET WORK.financial_aid;
    LENGTH AID_TYPE $ 20;
    AID_TYPE = 'Pell Grant %'; AID_PCT = PCT_PELL;       OUTPUT;
    AID_TYPE = 'Inst Grant %'; AID_PCT = PCT_INST_GRANT; OUTPUT;
    AID_TYPE = 'Loans %';      AID_PCT = PCT_LOANS;      OUTPUT;
    KEEP INST_NAME AID_TYPE AID_PCT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.aid_long;
    VBAR  INST_NAME / RESPONSE=AID_PCT GROUP=AID_TYPE
                      GROUPDISPLAY=CLUSTER DATALABEL;
    XAXIS LABEL=' ' FITPOLICY=ROTATE;
    YAXIS LABEL='Percent of Students' MIN=0 MAX=110;
    KEYLEGEND / TITLE='Aid Type';
    TITLE3 "7B: Financial Aid Landscape — All Peers 2023-24";
RUN;

DATA WORK.aid_amounts;
    SET WORK.financial_aid;
    LENGTH AID_TYPE $ 20;
    AID_TYPE = 'Avg Pell Grant'; AMT = AVG_PELL_AMT;   OUTPUT;
    AID_TYPE = 'Avg Inst Grant'; AMT = AVG_INST_GRANT; OUTPUT;
    AID_TYPE = 'Avg Loan';       AMT = AVG_LOAN_AMT;   OUTPUT;
    KEEP INST_NAME AID_TYPE AMT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.aid_amounts;
    VBAR  INST_NAME / RESPONSE=AMT GROUP=AID_TYPE
                      GROUPDISPLAY=CLUSTER DATALABEL
                      DATALABELATTRS=(SIZE=7);
    XAXIS LABEL=' ' FITPOLICY=ROTATE;
    YAXIS LABEL='Average Amount ($)' FORMAT=DOLLAR10.0;
    KEYLEGEND / TITLE='Aid Type';
    TITLE3 "7C: Average Aid Amounts — All Peers 2023-24";
RUN;


/* ============================================================
   SECTION 8 — DISTANCE EDUCATION
   ============================================================ */

TITLE3 "SECTION 8: Distance Education 2024";

PROC SQL;
    CREATE TABLE WORK.distance AS
    SELECT
        INST_NAME,
        PCTDEEXC AS PCT_EXCLUSIVELY_ONLINE,
        PCTDESOM AS PCT_SOME_ONLINE,
        PCTDENON AS PCT_NO_ONLINE,
        IS_BAYLOR
    FROM BAYDATA.clean_drvef2024
    ORDER BY IS_BAYLOR DESC, PCT_EXCLUSIVELY_ONLINE;
QUIT;

PROC PRINT DATA=WORK.distance NOOBS LABEL;
    VAR INST_NAME PCT_EXCLUSIVELY_ONLINE
        PCT_SOME_ONLINE PCT_NO_ONLINE;
    FORMAT PCT_EXCLUSIVELY_ONLINE PCT_SOME_ONLINE
           PCT_NO_ONLINE 5.1;
    LABEL INST_NAME               = 'Institution'
          PCT_EXCLUSIVELY_ONLINE  = '% Exclusively Online'
          PCT_SOME_ONLINE         = '% Some Online'
          PCT_NO_ONLINE           = '% No Online';
    TITLE3 "8A: Distance Education Patterns — All Peers 2024";
RUN;

DATA WORK.distance_long;
    SET WORK.distance;
    LENGTH DIST_TYPE $ 25;
    DIST_TYPE = 'Exclusively Online'; PCT = PCT_EXCLUSIVELY_ONLINE; OUTPUT;
    DIST_TYPE = 'Some Online';        PCT = PCT_SOME_ONLINE;        OUTPUT;
    DIST_TYPE = 'No Online';          PCT = PCT_NO_ONLINE;          OUTPUT;
    KEEP INST_NAME DIST_TYPE PCT IS_BAYLOR;
RUN;

PROC SGPLOT DATA=WORK.distance_long;
    HBAR  INST_NAME / RESPONSE=PCT GROUP=DIST_TYPE
                      GROUPDISPLAY=STACK DATALABEL;
    XAXIS LABEL='Percent of Students' MIN=0 MAX=105;
    YAXIS LABEL=' ';
    KEYLEGEND / TITLE='Distance Education';
    TITLE3 "8B: Distance Education Mix — All Peers 2024";
RUN;


/* ============================================================
   SECTION 9 — PEER BENCHMARKING SUMMARY
   NOTE: All joins to clean_hd2024 use PUT() to convert
         numeric UNITID to Char(6) for matching.
   ============================================================ */

TITLE3 "SECTION 9: Peer Benchmarking Summary";

PROC SQL;
    CREATE TABLE WORK.benchmark AS
    SELECT
        d.INSTNM                             AS INST_NAME,
        e.ENRTOT,
        e.EFUG,
        e.EFGRAD,
        ROUND(e.EFGRAD / e.ENRTOT * 100,0.1) AS GRAD_SHARE_PCT,
        ROUND(e.ENRFT  / e.ENRTOT * 100,0.1) AS FT_RATE_PCT,
        g.GBA6RTT                             AS GRAD_RATE_6YR,
        r.RET_PCF                             AS RETENTION_PCT,
        f.ANYAIDP                             AS PCT_ANY_AID,
        f.FGRNT_P                             AS PCT_PELL,
        f.IGRNT_A                             AS AVG_INST_GRANT,
        e.PCTENRHS                            AS PCT_HISPANIC,
        e.PCTENRBK                            AS PCT_BLACK,
        e.PCTENRW                             AS PCT_WOMEN,
        e.RMINSTTP                            AS PCT_INSTATE,
        d.IS_BAYLOR
    FROM BAYDATA.clean_drvef2024 e
    JOIN BAYDATA.clean_hd2024    d
        ON PUT(e.UNITID, 6.) = d.UNITID
    JOIN BAYDATA.clean_drvgr2024 g
        ON e.UNITID = g.UNITID
    JOIN BAYDATA.clean_ef2024d   r
        ON e.UNITID = r.UNITID
    JOIN BAYDATA.clean_sfa2324   f
        ON e.UNITID = f.UNITID
    ORDER BY d.IS_BAYLOR DESC, e.ENRTOT DESC;
QUIT;

/* 9A: Full benchmarking table */
PROC PRINT DATA=WORK.benchmark NOOBS LABEL;
    VAR INST_NAME ENRTOT GRAD_RATE_6YR RETENTION_PCT
        PCT_ANY_AID PCT_PELL AVG_INST_GRANT
        PCT_HISPANIC PCT_WOMEN PCT_INSTATE;
    FORMAT ENRTOT COMMA10.
           AVG_INST_GRANT DOLLAR10.0
           GRAD_RATE_6YR RETENTION_PCT PCT_ANY_AID
           PCT_PELL PCT_HISPANIC PCT_WOMEN PCT_INSTATE 5.1;
    LABEL INST_NAME      = 'Institution'
          ENRTOT         = 'Total Enrollment'
          GRAD_RATE_6YR  = 'Grad Rate 6-Yr'
          RETENTION_PCT  = 'Retention Rate'
          PCT_ANY_AID    = '% Any Aid'
          PCT_PELL       = '% Pell'
          AVG_INST_GRANT = 'Avg Inst Grant'
          PCT_HISPANIC   = '% Hispanic'
          PCT_WOMEN      = '% Women'
          PCT_INSTATE    = '% In-State';
    TITLE3 "9A: Comprehensive Peer Benchmarking Table — 2024";
RUN;

/* 9B: PROC RANK — Baylor vs peers */
PROC RANK DATA=WORK.benchmark OUT=WORK.benchmark_ranked
    DESCENDING TIES=MEAN;
    VAR GRAD_RATE_6YR RETENTION_PCT AVG_INST_GRANT;
    RANKS RANK_GRAD RANK_RETENTION RANK_INST_GRANT;
RUN;

PROC RANK DATA=WORK.benchmark_ranked OUT=WORK.benchmark_ranked;
    VAR PCT_PELL ENRTOT;
    RANKS RANK_PELL RANK_ENRTOT;
RUN;

PROC PRINT DATA=WORK.benchmark_ranked NOOBS LABEL;
    VAR INST_NAME GRAD_RATE_6YR RANK_GRAD
        RETENTION_PCT RANK_RETENTION
        AVG_INST_GRANT RANK_INST_GRANT
        PCT_PELL RANK_PELL;
    FORMAT GRAD_RATE_6YR RETENTION_PCT PCT_PELL 5.1
           AVG_INST_GRANT DOLLAR10.0;
    LABEL INST_NAME         = 'Institution'
          GRAD_RATE_6YR     = 'Grad Rate 6-Yr'
          RANK_GRAD         = 'Rank (Grad)'
          RETENTION_PCT     = 'Retention Pct'
          RANK_RETENTION    = 'Rank (Retention)'
          AVG_INST_GRANT    = 'Avg Inst Grant'
          RANK_INST_GRANT   = 'Rank (Inst Grant)'
          PCT_PELL          = '% Pell'
          RANK_PELL         = 'Rank (Pell)';
    TITLE3 "9B: Baylor Rankings Among Peers (1 = Best)";
RUN;

/* 9C: PROC MEANS — Baylor vs peer average */
PROC MEANS DATA=WORK.benchmark MAXDEC=1 N MEAN MIN MAX;
    CLASS IS_BAYLOR;
    VAR ENRTOT GRAD_RATE_6YR RETENTION_PCT
        PCT_ANY_AID PCT_PELL AVG_INST_GRANT
        PCT_HISPANIC PCT_WOMEN;
    LABEL IS_BAYLOR = 'Is Baylor (1=Yes 0=Peers)';
    TITLE3 "9C: PROC MEANS — Baylor vs Peer Average";
RUN;


/* ============================================================
   SECTION 10 — STATISTICAL MODELS
   PROC CORR, PROC MEANS, PROC REG, PROC LOGISTIC
   ============================================================ */

TITLE3 "SECTION 10: Statistical Analysis";

/* 10A: Correlation matrix */
PROC CORR DATA=WORK.benchmark NOSIMPLE NOPROB;
    VAR ENRTOT GRAD_RATE_6YR RETENTION_PCT
        PCT_ANY_AID PCT_PELL AVG_INST_GRANT
        PCT_HISPANIC PCT_WOMEN;
    TITLE3 "10A: PROC CORR — Correlation Matrix of Key Metrics";
RUN;

/* 10B: Descriptive statistics */
PROC MEANS DATA=WORK.benchmark
    N MEAN STD MIN MAX MEDIAN MAXDEC=1;
    VAR ENRTOT GRAD_RATE_6YR RETENTION_PCT
        PCT_ANY_AID PCT_PELL AVG_INST_GRANT;
    TITLE3 "10B: PROC MEANS — Descriptive Statistics All Peers";
RUN;

/* 10C: Linear regression — predict graduation rate */
PROC REG DATA=WORK.benchmark PLOTS=NONE;
    MODEL GRAD_RATE_6YR = PCT_ANY_AID PCT_WOMEN PCT_HISPANIC
        / STB;
    OUTPUT OUT=WORK.reg_out
           PREDICTED = PRED_GRAD_RATE
           RESIDUAL  = RESIDUAL;
    TITLE3 "10C: PROC REG — Predicting 6-Year Graduation Rate";
RUN;
QUIT;

/* 10D: Logistic regression — above/below median grad rate */
PROC SQL NOPRINT;
    SELECT MEDIAN(GRAD_RATE_6YR) INTO :MEDIAN_GRAD
    FROM WORK.benchmark
    WHERE GRAD_RATE_6YR IS NOT NULL;
QUIT;

DATA WORK.model_data;
    SET WORK.benchmark;
    WHERE GRAD_RATE_6YR IS NOT NULL
      AND PCT_ANY_AID   IS NOT NULL
      AND PCT_WOMEN     IS NOT NULL;
    HIGH_GRAD = (GRAD_RATE_6YR > &MEDIAN_GRAD.);
    LABEL HIGH_GRAD = 'Above-Median Grad Rate (1=Yes)';
RUN;

PROC LOGISTIC DATA=WORK.model_data DESCENDING;
    MODEL HIGH_GRAD = PCT_ANY_AID PCT_WOMEN PCT_HISPANIC
        / DETAILS RSQUARE;
    TITLE3 "10D: PROC LOGISTIC — Predicting Above-Median Grad Rate";
RUN;


/* ============================================================
   FINAL SUMMARY — BAYLOR REPORT CARD
   ============================================================ */

TITLE3 "FINAL: Baylor University 2024 Report Card";

DATA WORK.baylor_summary;
    LENGTH METRIC $ 40 VALUE $ 20 CONTEXT $ 50;
    METRIC='Total Enrollment';          VALUE='20,626';   CONTEXT='Declined from 20,824 in 2023';           OUTPUT;
    METRIC='Undergraduate Enrollment';  VALUE='14,915';   CONTEXT='72% of total enrollment';                OUTPUT;
    METRIC='Graduate Enrollment';       VALUE='5,711';    CONTEXT='28% of total — growing trend';           OUTPUT;
    METRIC='Full-Time Rate';            VALUE='91.2%';    CONTEXT='Higher than most peers';                 OUTPUT;
    METRIC='6-Year Graduation Rate';    VALUE='80%';      CONTEXT='Above peer median';                      OUTPUT;
    METRIC='First-Year Retention Rate'; VALUE='91%';      CONTEXT='Stable 2021-2024';                       OUTPUT;
    METRIC='% Women';                   VALUE='61%';      CONTEXT='Consistent across all years';            OUTPUT;
    METRIC='% Hispanic';                VALUE='17%';      CONTEXT='Increased from 15% in 2021';             OUTPUT;
    METRIC='% In-State Freshmen';       VALUE='63%';      CONTEXT='Strong Texas regional draw';             OUTPUT;
    METRIC='% Receiving Any Aid';       VALUE='99%';      CONTEXT='Nearly universal aid coverage';          OUTPUT;
    METRIC='% Receiving Pell Grant';    VALUE='10%';      CONTEXT='Low vs peers — selective admissions';    OUTPUT;
    METRIC='Avg Institutional Grant';   VALUE='$25,690';  CONTEXT='High institutional investment in aid';   OUTPUT;
    METRIC='% Receiving Loans';         VALUE='38%';      CONTEXT='Lower than most peers';                  OUTPUT;
    METRIC='Student-Faculty Ratio';     VALUE='15:1';     CONTEXT='Good instructional access';              OUTPUT;
RUN;

PROC PRINT DATA=WORK.baylor_summary NOOBS LABEL;
    VAR METRIC VALUE CONTEXT;
    LABEL METRIC  = 'Metric'
          VALUE   = 'Value'
          CONTEXT = 'Context / Trend';
    TITLE3 "Baylor University 2024 Report Card — Key Metrics";
RUN;

ODS GRAPHICS OFF;
TITLE; TITLE2; TITLE3;


/* ============================================================
   SECTION 11 — EXPORT GOLD LAYER FOR POWER BI
   Exports 10 Gold CSV files to BAYLOR\data\ folder
   Load these into Power BI Desktop to build dashboard
   ============================================================ */

TITLE3 "SECTION 11: Exporting Gold Layer for Power BI";

PROC EXPORT DATA=WORK.benchmark
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_benchmark.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.enroll_trend
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_enroll_trend.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.grad_rates
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_grad_rates.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.financial_aid
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_financial_aid.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.retention
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_retention.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.demographics
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_demographics.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.residency
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_residency.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.diversity_long
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_diversity.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=WORK.baylor_summary
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_baylor_summary.csv"
    DBMS=CSV REPLACE;
RUN;

PROC EXPORT DATA=BAYDATA.clean_hd2024
    OUTFILE="\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gold_dim_institution.csv"
    DBMS=CSV REPLACE;
RUN;

%PUT NOTE: ==========================================================;
%PUT NOTE: PROGRAM 11 COMPLETE Kelly Adu-Gyamfi;
%PUT NOTE: All sections run. Gold CSVs exported to:;
%PUT NOTE:   Desktop\BAYLOR\data\;
%PUT NOTE: Next step: Open Power BI Desktop and load Gold CSVs;
%PUT NOTE: ==========================================================;
