/* ============================================================
   PROGRAM  : 08_import_clean_hd2024.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Directory Information 2024
   SOURCE   : hd2024.csv
   OUTPUT   : BAYDATA.clean_hd2024
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Decode CONTROL type to descriptive label
     - Decode SECTOR and HBCU to descriptive labels
     - Recode -2 N/A codes to SAS missing (.)
       NEWID, DEATHYR = -2 means institution is active
       F1SYSCOD, CSA = -2 means not applicable
     - Keep analysis-relevant columns only
     - Add Baylor flag and apply variable labels
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\hd2024.csv"
    OUT      = BAYDATA.raw_hd2024
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;


DATA BAYDATA.clean_hd2024;
    SET BAYDATA.raw_hd2024;

    WHERE UNITID IN ('223232','228875','228246','228723',
                     '228778','162928','221999');

    IS_BAYLOR = (UNITID = '223232');

    LENGTH CONTROL_LABEL $ 30;
    SELECT (CONTROL);
        WHEN (1) CONTROL_LABEL = 'Public';
        WHEN (2) CONTROL_LABEL = 'Private Not-for-Profit';
        WHEN (3) CONTROL_LABEL = 'Private For-Profit';
        OTHERWISE CONTROL_LABEL = 'Unknown';
    END;

    LENGTH SECTOR_LABEL $ 40;
    SELECT (SECTOR);
        WHEN (1) SECTOR_LABEL = 'Public, 4-year or above';
        WHEN (2) SECTOR_LABEL = 'Private NFP, 4-year or above';
        WHEN (3) SECTOR_LABEL = 'Private FP, 4-year or above';
        OTHERWISE SECTOR_LABEL = 'Other';
    END;

    LENGTH HBCU_LABEL $ 5;
    IF HBCU = 1 THEN HBCU_LABEL = 'Yes';
    ELSE             HBCU_LABEL = 'No';

    IF NEWID    = -2 THEN NEWID    = .;
    IF DEATHYR  = -2 THEN DEATHYR  = .;
    IF F1SYSCOD = -2 THEN F1SYSCOD = .;
    IF CSA      = -2 THEN CSA      = .;

    LABEL
        UNITID        = 'Institution UNITID'
        INSTNM        = 'Institution Name'
        CITY          = 'City'
        STABBR        = 'State Abbreviation'
        CONTROL       = 'Control Type Code'
        CONTROL_LABEL = 'Control Type Description'
        SECTOR_LABEL  = 'Sector Description'
        HBCU_LABEL    = 'HBCU Status'
        LOCALE        = 'Locale Code'
        INSTSIZE      = 'Institution Size Category'
        LATITUDE      = 'Latitude'
        LONGITUD      = 'Longitude (Negative = West of Meridian)'
        IS_BAYLOR     = 'Baylor Flag (1=Yes)'
        CHFNM         = 'Chief Administrator Name'
        WEBADDR       = 'Institution Website';

    KEEP UNITID INSTNM IALIAS ADDR CITY STABBR ZIP
         CONTROL CONTROL_LABEL SECTOR SECTOR_LABEL
         HBCU HBCU_LABEL LOCALE INSTSIZE
         LATITUDE LONGITUD CHFNM CHFTITLE WEBADDR
         LANDGRNT C21BASIC CARNEGIERSCH
         F1SYSTYP F1SYSNAM IS_BAYLOR;
RUN;

PROC PRINT DATA = BAYDATA.CLEAN_HD2024 NOOBS;
    VAR UNITID INSTNM CITY STABBR CONTROL_LABEL
        HBCU_LABEL INSTSIZE IS_BAYLOR;
    TITLE 'CLEAN_HD2024 7 Peer Institutions';
RUN;
