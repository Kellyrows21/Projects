/* ============================================================
   PROGRAM  : 07_import_clean_gr2024.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Graduation Rates 2024
   SOURCE   : gr2024.csv
   OUTPUT   : BAYDATA.clean_gr2024
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Filter to Bachelor's cohort summary rows only:
       GRTYPE=1, CHRTSTAT=10, LINE='999'
       Reduces 51,011 rows down to 7 summary rows
     - Drop all 30 X-flag indicator columns
     - Add institution name and Baylor flag
     - Apply descriptive variable labels
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";
PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\gr2024.csv"
    OUT      = BAYDATA.raw_gr2024
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;
DATA BAYDATA.clean_gr2024;
    SET BAYDATA.raw_gr2024;
    WHERE UNITID   IN (223232,228875,228246,228723,228778,162928,221999)
      AND GRTYPE   = 1
      AND CHRTSTAT = 10
      AND LINE     = '999';
    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;
    IS_BAYLOR = (UNITID = 223232);
    LABEL
        UNITID    = 'Institution UNITID'
        INST_NAME = 'Institution Name'
        IS_BAYLOR = 'Baylor Flag (1=Yes)'
        GRTOTLT   = 'Graduates Total (150% time)'
        GRTOTLM   = 'Graduates Male'
        GRTOTLW   = 'Graduates Female'
        GRBKAAT   = 'Graduates Black/African American'
        GRHISPT   = 'Graduates Hispanic/Latino'
        GRWHITT   = 'Graduates White'
        GRASIAT   = 'Graduates Asian'
        GRNRALT   = 'Graduates Nonresident Alien'
        GR2MORT   = 'Graduates Two or More Races';
    DROP XGRTOTLT XGRTOTLM XGRTOTLW XGRAIANT XGRAIANM
         XGRAIANW XGRASIAT XGRASIAM XGRASIAW XGRBKAAT
         XGRBKAAM XGRBKAAW XGRHISPT XGRHISPM XGRHISPW
         XGRNHPIT XGRNHPIM XGRNHPIW XGRWHITT XGRWHITM
         XGRWHITW XGR2MORT XGR2MORM XGR2MORW XGRUNKNT
         XGRUNKNM XGRUNKNW XGRNRALT XGRNRALM XGRNRALW;
RUN;
PROC PRINT DATA = BAYDATA.CLEAN_GR2024 NOOBS;
    VAR UNITID INST_NAME GRTOTLT GRTOTLM GRTOTLW
        GRBKAAT GRHISPT GRWHITT IS_BAYLOR;
    TITLE 'CLEAN_GR2024 7 Summary Rows';
RUN;
