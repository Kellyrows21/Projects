/* ============================================================
   PROGRAM  : 05_import_clean_drvgr2024.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Graduation Rates 2024
   SOURCE   : drvgr2024.csv
   OUTPUT   : BAYDATA.clean_drvgr2024
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Add institution name and Baylor flag
     - Keep suppressed small cells as missing (NOT zero)
       GRRTNH, GRRTUN, GBA6RTNH, GBA6RTUN = suppressed
       Setting to 0 would incorrectly imply 0% grad rate
     - Apply descriptive variable labels
   NOTE: GBA6RTT = 6-year Bachelor's graduation rate (150%)
         This is the primary column for analysis.
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\drvgr2024.csv"
    OUT      = BAYDATA.raw_drvgr2024
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;

DATA BAYDATA.clean_drvgr2024;
    SET BAYDATA.raw_drvgr2024;

    WHERE UNITID IN (223232,228875,228246,228723,228778,162928,221999);

    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;

    IS_BAYLOR = (UNITID = 223232);

    LABEL
        UNITID    = 'Institution UNITID'
        INST_NAME = 'Institution Name'
        IS_BAYLOR = 'Baylor Flag (1=Yes)'
        GBA6RTT   = '6-Yr Bach Grad Rate Total Pct (150%)'
        GBA6RTM   = '6-Yr Bach Grad Rate Men Pct'
        GBA6RTW   = '6-Yr Bach Grad Rate Women Pct'
        GBA6RTBK  = '6-Yr Bach Grad Rate Black Pct'
        GBA6RTHS  = '6-Yr Bach Grad Rate Hispanic Pct'
        GBA6RTWH  = '6-Yr Bach Grad Rate White Pct'
        GBA6RTAP  = '6-Yr Bach Grad Rate Asian/PI Pct'
        GBA4RTT   = '4-Yr Bach Grad Rate Total Pct (100%)'
        GBA5RTT   = '5-Yr Bach Grad Rate Total Pct (125%)'
        PGGRRTT   = 'Grad Rate Pell Grant Recipients Pct'
        PGBA6RT   = '6-Yr Bach Grad Rate Pell Pct'
        SSGRRTT   = 'Grad Rate Direct Loan Recipients Pct'
        SSBA6RT   = '6-Yr Bach Grad Rate Loan Pct'
        NRGRRTT   = 'Grad Rate Non-Recipient Students Pct'
        NRBA6RT   = '6-Yr Bach Grad Rate Non-Recipient Pct';
RUN;

PROC PRINT DATA = BAYDATA.CLEAN_DRVGR2024 NOOBS;
    VAR UNITID INST_NAME GBA4RTT GBA5RTT GBA6RTT
        GBA6RTBK GBA6RTHS GBA6RTWH PGGRRTT IS_BAYLOR;
    TITLE 'CLEAN_DRVGR2024 Graduation Rates';
    FORMAT GBA4RTT GBA5RTT GBA6RTT GBA6RTBK
           GBA6RTHS GBA6RTWH PGGRRTT 5.1;
RUN;
