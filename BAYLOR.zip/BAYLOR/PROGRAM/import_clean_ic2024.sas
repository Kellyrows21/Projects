/* ============================================================
   PROGRAM  : 09_import_clean_ic2024.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Inst Characteristics 2024
   SOURCE   : ic2024.csv
   OUTPUT   : BAYDATA.clean_ic2024
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Decode CNTLAFFI including code 4 = Private NFP
       Religious (Baylor is Baptist university = code 4)
     - Decode CALSYS (calendar system) to label
     - Recode -2 N/A codes to SAS missing (.)
       PUBPRIME, PUBSECON = -2 for private institutions
       RELAFFIL = -2 for non-religious institutions
       YRSCOLL = -2 for institutions not using credit years
       CONFNO3 = -2 for institutions with fewer than 3 sports
     - DISABPCT null = suppressed small cell, leave as .
     - Keep analysis-relevant columns only
     - Add Baylor flag and apply variable labels
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\ic2024.csv"
    OUT      = BAYDATA.raw_ic2024
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;

DATA BAYDATA.clean_ic2024;
    SET BAYDATA.raw_ic2024;

    WHERE UNITID IN (223232,228875,228246,228723,228778,162928,221999);

    IS_BAYLOR = (UNITID = 223232);

    /* CORRECTED CNTLAFFI decode based on actual codes
       found in ic2024 via PROC FREQ:
       1 = Public
       3 = Private Not-for-Profit (no code 2 exists here)
       4 = Private NFP Religious                          */
    LENGTH CNTLAFFI_LABEL $ 30;
    SELECT (CNTLAFFI);
        WHEN (1) CNTLAFFI_LABEL = 'Public';
        WHEN (3) CNTLAFFI_LABEL = 'Private Not-for-Profit';
        WHEN (4) CNTLAFFI_LABEL = 'Private NFP - Religious';
        OTHERWISE CNTLAFFI_LABEL = 'Unknown';
    END;

    LENGTH CALSYS_LABEL $ 20;
    SELECT (CALSYS);
        WHEN (1) CALSYS_LABEL = 'Semester';
        WHEN (2) CALSYS_LABEL = 'Quarter';
        WHEN (3) CALSYS_LABEL = 'Trimester';
        WHEN (4) CALSYS_LABEL = 'Four-one-four';
        OTHERWISE CALSYS_LABEL = 'Other';
    END;

    IF PUBPRIME = -2 THEN PUBPRIME = .;
    IF PUBSECON = -2 THEN PUBSECON = .;
    IF RELAFFIL = -2 THEN RELAFFIL = .;
    IF YRSCOLL  = -2 THEN YRSCOLL  = .;
    IF CONFNO3  = -2 THEN CONFNO3  = .;

    LABEL
        UNITID         = 'Institution UNITID'
        IS_BAYLOR      = 'Baylor Flag (1=Yes)'
        CNTLAFFI       = 'Control/Affiliation Code'
        CNTLAFFI_LABEL = 'Control/Affiliation Description'
        CALSYS_LABEL   = 'Calendar System'
        RELAFFIL       = 'Religious Affiliation Code'
        LEVEL1         = 'Offers Bachelors (1=Yes)'
        LEVEL3         = 'Offers Masters (1=Yes)'
        LEVEL5         = 'Offers Doctoral (1=Yes)'
        FT_UG          = 'Has Full-Time UG Program (1=Yes)'
        DSTNUGC        = 'Distance UG Courses Offered'
        DSTNGC         = 'Distance Grad Courses Offered'
        DISAB          = 'Disability Services (1=Yes)'
        DISABPCT       = 'Pct Students with Disabilities'
        OPENADMP       = 'Open Admissions (1=Yes)';

    KEEP UNITID CNTLAFFI CNTLAFFI_LABEL CALSYS CALSYS_LABEL
         RELAFFIL LEVEL1 LEVEL3 LEVEL5
         FT_UG FT_FTUG FTGDNIDP
         DSTNUGC DSTNGC DISTCRS DISTPGS
         DISAB DISABPCT OPENADMP
         ATHASSOC SPORT1 SPORT2 SPORT3 SPORT4
         IS_BAYLOR;
RUN;

PROC PRINT DATA = BAYDATA.CLEAN_IC2024 NOOBS;
    VAR UNITID CNTLAFFI CNTLAFFI_LABEL CALSYS_LABEL
        LEVEL1 LEVEL3 LEVEL5 DISAB DISABPCT IS_BAYLOR;
    TITLE 'CLEAN_IC2024 Institutional Characteristics';
RUN;
