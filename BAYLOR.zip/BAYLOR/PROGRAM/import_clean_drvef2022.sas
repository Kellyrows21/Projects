/* ============================================================
   PROGRAM  : import_clean_drvef2022.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Fall Enrollment 2022
   SOURCE   : drvef2022.csv
   OUTPUT   : BAYDATA.clean_drvef2022
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Add institution name, Baylor flag, academic year
     - Convert mixed-type columns to numeric with INPUT()
       (drvef2022 uses '.' for missing in char columns)
     - Fix trailing-space column name STUFACR
     - Drop original character versions of converted cols
     - Apply descriptive variable labels
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";
PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\drvef2022.csv"
    OUT      = BAYDATA.raw_drvef2022
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;
DATA BAYDATA.clean_drvef2022;
    SET BAYDATA.raw_drvef2022;
    WHERE UNITID IN (223232,228875,228246,228723,228778,162928,221999);
    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;
    IS_BAYLOR = (UNITID = 223232);
    ACAD_YEAR = 2022;
    /* All columns already numeric � direct rename only      */
    /* PROC IMPORT handled all type conversion automatically  */
    RET_PCF_N  = RET_PCF;
    RET_PCP_N  = RET_PCP;
    PGRCOHRT_N = PGRCOHRT;
    STUFACR_N  = STUFACR;
    LABEL
        UNITID     = 'Institution UNITID'
        INST_NAME  = 'Institution Name'
        ACAD_YEAR  = 'Academic Year'
        IS_BAYLOR  = 'Baylor Flag (1=Yes)'
        ENRTOT     = 'Total Enrollment'
        EFUG       = 'Undergrad Enrollment'
        EFGRAD     = 'Graduate Enrollment'
        STUFACR_N  = 'Student to Faculty Ratio'
        RET_PCF_N  = 'Full-Time Retention Rate Pct'
        RET_PCP_N  = 'Part-Time Retention Rate Pct'
        RMINSTTN   = 'Freshmen In-State Count'
        RMOUSTTN   = 'Freshmen Out-of-State Count'
        RMINSTTP   = 'Pct Freshmen In-State'
        RMOUSTTP   = 'Pct Freshmen Out-of-State';
    /* No DROP needed � originals can stay alongside copies  */
RUN;
PROC PRINT DATA = BAYDATA.CLEAN_DRVEF2022 NOOBS;
    VAR UNITID INST_NAME ACAD_YEAR ENRTOT EFUG
        EFGRAD RET_PCF_N STUFACR IS_BAYLOR;
    TITLE 'CLEAN_DRVEF2022 7 Peer Institutions';
RUN;
