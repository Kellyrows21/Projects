/* ============================================================
   PROGRAM  : import_clean_ef2024d.sas
   AUTHOR   : KELLY ADU-GYAMFI
   PURPOSE  : Import and clean IPEDS Retention Rates 2024
   SOURCE   : ef2024d.csv
   OUTPUT   : BAYDATA.clean_ef2024d
   CLEANING :
     - Filter to 7 peer institutions (correct UNITIDs)
     - Add institution name and Baylor flag
     - Drop all 15 X-flag indicator columns
     - Calculate retention rate from raw cohort counts
     - Leave part-time retention nulls as missing (N/A for
       full residential universities not an error)
     - Apply descriptive variable labels
   NOTE: RRFTCT / GRCOHRT = true IPEDS full-time retention.
         RET_PCF is the official IPEDS retention rate pct.
   ============================================================ */

LIBNAME BAYDATA "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\LIBREF";

PROC IMPORT
    DATAFILE = "\\apporto.com\dfs\WCUPA\Users\1052757_wcupa\Desktop\BAYLOR\data\ef2024d.csv"
    OUT      = BAYDATA.raw_ef2024d
    DBMS     = CSV
    REPLACE;
    GUESSINGROWS = MAX;
RUN;

DATA BAYDATA.clean_ef2024d;
    SET BAYDATA.raw_ef2024d;
    WHERE UNITID IN (223232,228875,228246,228723,228778,162928,221999);
    LENGTH INST_NAME $ 40;
    SELECT (UNITID);
        WHEN (223232) INST_NAME = 'Baylor University';
        WHEN (228875) INST_NAME = 'Texas Christian University';
        WHEN (228246) INST_NAME = 'Southern Methodist University';
        WHEN (228723) INST_NAME = 'Texas A&M University';
        WHEN (228778) INST_NAME = 'Univ of Texas at Austin';
        WHEN (162928) INST_NAME = 'Johns Hopkins University';
        WHEN (221999) INST_NAME = 'Vanderbilt University';
        OTHERWISE     INST_NAME = 'Unknown';
    END;
    IS_BAYLOR = (UNITID = 223232);
/*calculated correctly by IPEDS. Do not recalculate.      */
RETENTION_FT_PCT = RET_PCF;
    LABEL
        UNITID           = 'Institution UNITID'
        INST_NAME        = 'Institution Name'
        IS_BAYLOR        = 'Baylor Flag (1=Yes)'
        GRCOHRT          = 'Prior Year Entering Cohort Size'
        UGENTERN         = 'Total Entering Undergrads Fall 2024'
        PGRCOHRT         = 'Pct Entering Who Are First-Time'
        RRFTCT           = 'Full-Time Students Retained Count'
        RET_PCF          = 'Full-Time Retention Rate Pct (IPEDS)'
        RETENTION_FT_PCT = 'Calculated Full-Time Retention Rate Pct'
        RET_PCP          = 'Part-Time Retention Rate Pct (IPEDS)'
        STUFACR          = 'Student to Faculty Ratio';
    /* Drop X-flag quality indicator columns                  */
    DROP XGRCOHRT XUGENTER XPGRCOHR XRRFTCT XRRFTEX
         XRRFTIN XRRFTCTA XRET_NMF XRET_PCF XRRPTCT
         XRRPTEX XRRPTIN XRRPTCTA XRET_NMP XRET_PCP XSTUFACR;
RUN;

PROC PRINT DATA = BAYDATA.CLEAN_EF2024D NOOBS;
    VAR UNITID INST_NAME GRCOHRT RRFTCT
        RET_PCF RETENTION_FT_PCT STUFACR IS_BAYLOR;
    TITLE 'CLEAN_EF2024D Retention Rates';
    FORMAT RET_PCF RETENTION_FT_PCT 5.1;
RUN;
